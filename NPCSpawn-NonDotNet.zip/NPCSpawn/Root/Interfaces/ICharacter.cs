﻿using System.Collections.Generic;
using System.Numerics;

namespace NPCSpawn
{
    interface ICharacter
    {
        // Properties
        CharacterID ID { get; set; }
        IDialogs Dialogs { get; set; }

        LocationID currentLocation { get; set; }
        IRoutines Routines { get; set; }
        Vector2 Coords { get; set; }

        // Methods
        void Talk();
        void Behave();
    }

    interface ICharacter_Marry : ICharacter
    {
        bool Married { get; }
    }
}