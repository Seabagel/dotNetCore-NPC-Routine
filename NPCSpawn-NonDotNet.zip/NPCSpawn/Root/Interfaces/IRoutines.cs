﻿using System.Collections.Generic;

namespace NPCSpawn
{
    interface IRoutines
    {
        List<Schedule> ScheduleList { get; set; }
        void Refresh(ICharacter_Marry npc);
    }
}