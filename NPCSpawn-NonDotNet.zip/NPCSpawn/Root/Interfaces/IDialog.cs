﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPCSpawn
{
    interface IDialogs
    {
         List<string> Dialog { get; set; }
        Dictionary<LocationID, List<string>> MarriedDialogs { get; set; }
        Dictionary<LocationID, List<string>> SingleDialogs { get; set; }
    }
}
