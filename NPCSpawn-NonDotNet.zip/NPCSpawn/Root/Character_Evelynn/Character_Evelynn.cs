﻿using System.Numerics;

namespace NPCSpawn
{
    class Character_Evelynn : ICharacter_Marry
    {
        public CharacterID ID { get; set; }
        public bool Married { get; }

        // Location
        public Vector2 Coords { get; set; }
        public LocationID currentLocation { get; set; }

        // Routines/Schedule
        public IRoutines Routines { get; set; }

        // Dialogs
        public IDialogs Dialogs { get; set; }

        public Character_Evelynn()
        {
            ID = CharacterID.Evelynn;
            Married = false;
            Routines = new Character_Evelynn_Routines(this);
            Dialogs = new Character_Evelynn_Dialogs();
        }

        public void Talk()
        {
            // Use Dialog
        }

        public void Behave()
        {
            // Follow Routine
        }
    }
}
