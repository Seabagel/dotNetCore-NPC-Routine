﻿using System.Collections.Generic;

namespace NPCSpawn
{
    class Character_Evelynn_Dialogs : IDialogs
    {
        public List<string> Dialog { get; set; }
        public Dictionary<LocationID, List<string>> MarriedDialogs { get; set; }
        public Dictionary<LocationID, List<string>> SingleDialogs { get; set; }

        // Dialogs
        public Character_Evelynn_Dialogs() =>
        SingleDialogs = new Dictionary<LocationID, List<string>>
        {
            { LocationID.SunsetBeach, new List<string>() }
        };

    }
}
