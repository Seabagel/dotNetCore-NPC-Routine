﻿using System.Collections.Generic;

namespace NPCSpawn
{
    class Character_Evelynn_Routines : IRoutines
    {
        public List<Schedule> ScheduleList { get; set; }

        public Character_Evelynn_Routines(ICharacter_Marry npc)
        {
            Refresh(npc);
        }

        public void Refresh(ICharacter_Marry npc)
        {
            // Make a new empty list
            ScheduleList = new List<Schedule>();

            // Fill it with these schedules
            if (!npc.Married)
            {
                switch (Current.calendar.GetDayOfWeek())
                {
                    case DayID.Tuesday:
                        ScheduleList.Add(new Schedule(
                            new Time(8, 30, true),
                            LocationID.Church,
                            npc.ID)
                        );
                        break;
                    default:
                        ScheduleList.Add(new Schedule(
                            new Time(8, 30, true),
                            LocationID.Church,
                            npc.ID)
                        );
                        break;
                }
                if (Current.calendar.HasDayofWeek(DayID.Monday))
                {

                }
            }

        }
    }
}
