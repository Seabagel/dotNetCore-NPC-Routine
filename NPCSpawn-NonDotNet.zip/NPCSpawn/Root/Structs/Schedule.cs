﻿namespace NPCSpawn
{
    struct Schedule
    {
        // Time and day
        public Time time;
        // Location and character
        public LocationID destination;
        public CharacterID characterID;

        public Schedule(Time time, LocationID destination, CharacterID characterID)
        {
            this.time = time;
            this.destination = destination;
            this.characterID = characterID;
        }
    }
}