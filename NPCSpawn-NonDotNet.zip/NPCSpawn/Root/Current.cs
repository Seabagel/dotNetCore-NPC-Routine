﻿using System.Collections.Generic;
using System.Linq;

namespace NPCSpawn
{
    static class Current
    {
        // List of all Characters
        public static Characters characters = new Characters();
         
        // All NPC Routines
        public static RoutineSystem jobSystem = new RoutineSystem();

        // Tracks the the day and time
        public static Calendar calendar = new Calendar(1);
        public static Time time = new Time(6, 0, true);

        // Weather
        public static bool raining = false;
    }

    class Characters
    {
        // Keeps all the Characters in a Location
        // NPCs are created dynamically by the Location.
        public Dictionary<CharacterID, ICharacter> List;

        public Characters()
        {
            // Adding Characters
            List = new Dictionary<CharacterID, ICharacter>
            {
                { CharacterID.Evelynn , new Character_Evelynn() }
            };
        }
    }

    class RoutineSystem
    {
        public List<Schedule> ScheduleList;

        public RoutineSystem()
        {
            ScheduleList = new List<Schedule>();
        }

        // Refreshes schedules
        public void RefreshList()
        {
            ScheduleList = new List<Schedule>();
            foreach (var character in Current.characters.List.Values)
            {
                foreach (var schedule in character.Routines.ScheduleList)
                {
                    ScheduleList.Add(schedule);
                }
            }

            // Sorts list
            ScheduleList.OrderBy(schedule => schedule.time.minutes).ToList();
        }
    }
}
