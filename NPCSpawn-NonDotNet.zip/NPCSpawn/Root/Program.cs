﻿using System;

namespace NPCSpawn
{
    class Program
    {
        static void Main(string[] args)
        {
            // Console log the Schedules
            Console.WriteLine();
            //WriteList();
             
            // Wait for input
            Console.ReadLine();
        }

        private static void WriteList()
        {
            /*
             // Write ScheduleDays sorted by Day
            Console.WriteLine($"  ScheduleDays Sorted by Day:");
            foreach (var character in MasterList.NPC)
            {
                Console.WriteLine($"  - {character.ID}:");
                foreach (var dayschedule in character.DaySchedules)
                {
                    Console.WriteLine($"    - {dayschedule.ID}:");
                    foreach (var schedule in dayschedule.Schedules)
                    {
                        Console.WriteLine($"       - {schedule.Hour.Get12F()}, {schedule.Location}");
                    }
                }
            }
             */
        }

        // End of Main
    }
}
